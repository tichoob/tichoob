Tichoob Digital Card

Upload this ZIP to https://ship.page/ to publish. The logo is embedded in index.html.
Links: Instagram @Tichoob, Telegram https://t.me/tichoob, phone 09136212032.
Note: ship.page free hosting displays its own closeable badge; removing it permanently may require a paid plan. Free links are temporary.
